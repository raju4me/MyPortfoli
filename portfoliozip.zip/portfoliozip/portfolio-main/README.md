# portfolio
My personal portfolio website coded in HTML, CSS, JavaScript and Bootstrap.
You can fork this and make yours.

## Getting Started
- Fork the repository to make it yours.
- Rename the forked repository to 'username.github.io', where username is your GitHub username.
- Edit the HTML pages according to your own
- That's it! Navigate to 'username.github.io' to see your website :)

## Credits
- <a href="https://github.com/Bloggify/github-calendar" target=_blank> Github Calendar by Bloggify </a>
- <a href="https://github.com/soumyajit4419/Portfolio" target=_blank> Soumyajit Behera </a>
- <a href="https://github.com/nrandecker/particle" target=_blank> Nathan Randecker </a>
